
#ifndef ARMOR_DETECTOR__NUMBER_ClASSIFIER_HPP_
#define ARMOR_DETECTOR__NUMBER_ClASSIFIER_HPP_

#include "openvino_armor_detector/types.hpp"
#include <vector>
#include <string>
#include <opencv2/dnn.hpp>
#include <opencv2/opencv.hpp>
namespace rm_auto_aim
{

    class NumberClassifier
    {

    private:
        cv::dnn::Net net_;
        std::vector<std::string> class_names_ = {
            "1", "2", "3", "4", "5", "outpost", "guard", "base", "negative"};
        int light_length_ = 12;
        // Image size after warp
        int warp_height_ = 28;
        int small_armor_width_ = 32;
        int large_armor_width_ = 54;

    public:
        NumberClassifier(const std::string &model_path)
        {
            net_ = cv::dnn::readNetFromONNX(model_path);
        }
        ~NumberClassifier() {}

        void extractNumbers(const cv::Mat &src, std::vector<ArmorObject> &armors)
        {

            // Number ROI size
            const cv::Size roi_size(20, 28);

            for (auto &armor : armors)
            {
                // Warp perspective transform
                if (armor.pts[0].x <= 0 || armor.pts[0].y <= 0 || armor.pts[1].x <= 0 || armor.pts[1].y >= src.rows || armor.pts[2].x >= src.cols || armor.pts[2].y >= src.rows || armor.pts[3].x >= src.cols || armor.pts[3].y <= 0)
                {
                    continue;
                }
                cv::Point2f lights_vertices[4] = {armor.pts[1], armor.pts[0], armor.pts[3], armor.pts[2]};

                const int top_light_y = (warp_height_ - light_length_) / 2 - 1;
                const int bottom_light_y = top_light_y + light_length_;
                const int warp_width = armor.type == ArmorType::BIG ? large_armor_width_ : small_armor_width_;
                cv::Point2f target_vertices[4] = {
                    cv::Point(0, bottom_light_y),
                    cv::Point(0, top_light_y),
                    cv::Point(warp_width - 1, top_light_y),
                    cv::Point(warp_width - 1, bottom_light_y),
                };
                cv::Mat number_image;
                auto rotation_matrix = cv::getPerspectiveTransform(lights_vertices, target_vertices);

                cv::warpPerspective(src, number_image, rotation_matrix, cv::Size(warp_width, warp_height_));

                // Get ROI
                number_image =
                    number_image(cv::Rect(cv::Point((warp_width - roi_size.width) / 2, 0), roi_size));

                // Binarize
                std::vector<cv::Mat> channels(3);
                cv::split(number_image, channels);

                cv::cvtColor(number_image, number_image, cv::COLOR_RGB2GRAY);
                // 保存数字图案20*28
                //  cv::imwrite("/home/gx/rm_classifier_training-main/补_/"+std::to_string(num++)+".jpg", number_image);
                cv::threshold(number_image, number_image, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);
                // cv::Mat number_img_ = perform_opening(number_image,2);

                armor.number_img = number_image;
            }
        }

        void classify(cv::Mat src, std::vector<ArmorObject> &armors)
        {
            extractNumbers(src, armors);

            for (auto &armor : armors)
            {
                cv::Mat image = armor.number_img.clone();
                if (armor.number_img.empty())
                {
                    continue;
                }

                // Normalize
                image = image / 255.0;

                // Create blob from image
                cv::Mat blob;
                cv::dnn::blobFromImage(image, blob);

                // Set the input blob for the neural network
                net_.setInput(blob);
                // Forward pass the image blob through the model
                cv::Mat outputs = net_.forward();

                // Do softmax
                float max_prob = *std::max_element(outputs.begin<float>(), outputs.end<float>());
                cv::Mat softmax_prob;
                cv::exp(outputs - max_prob, softmax_prob);
                float sum = static_cast<float>(cv::sum(softmax_prob)[0]);
                softmax_prob /= sum;

                double confidence;
                cv::Point class_id_point;
                minMaxLoc(softmax_prob.reshape(1, 1), nullptr, &confidence, nullptr, &class_id_point);
                int label_id = class_id_point.x;
                if (class_names_[label_id] != "negative")
                {
                    armor.number = class_names_[label_id];
                }
            }

            armors.erase(
                std::remove_if(armors.begin(), armors.end(),
                               [this](const ArmorObject &armor)
                               {
                                   //    if (armor.number == "negative")
                                   //    {
                                   //        return true;
                                   //    }
                                   if (armor.number_img.empty())
                                   {
                                       return true;
                                   }
                                   bool mismatch_armor_type = false;
                                   if (armor.type == ArmorType::BIG)
                                   {
                                       mismatch_armor_type = armor.number == "outpost" ||
                                                             armor.number == "2" ||
                                                             armor.number == "guard";
                                   }
                                   else if (armor.type == ArmorType::SMALL)
                                   {
                                       mismatch_armor_type =
                                           armor.number == "1" || armor.number == "base";
                                   }
                                   return mismatch_armor_type;
                               }),
                armors.end());
        }
    };

}

#endif // NUMBER_CLASSIFIER_HPP