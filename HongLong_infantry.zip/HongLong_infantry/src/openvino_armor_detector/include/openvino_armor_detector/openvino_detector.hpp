// Copyright 2023 Yunlong Feng
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef OPENVINO_ARMOR_DETECTOR__OPENVINO_DETECTOR_HPP_
#define OPENVINO_ARMOR_DETECTOR__OPENVINO_DETECTOR_HPP_

#include <Eigen/Dense>

#include <cmath>
#include <filesystem>
#include <functional>
#include <future>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <opencv2/opencv.hpp>
#include <openvino/openvino.hpp>
#include<openvino_armor_detector/number_classifier.hpp>
#include <openvino_armor_detector/types.hpp>

namespace rm_auto_aim
{

  struct GridAndStride
  {
    int grid0;
    int grid1;
    int stride;
  };

  // width / height
  const double min_ratio = 0.1;
  const double max_ratio = 0.5;
  // vertical angle
  const double light_max_angle = 40;

  const double min_light_ratio = 0.7;
  const double min_small_center_distance = 0.8;
  const double max_small_center_distance = 3.2;
  const double min_large_center_distance = 3.2;
  const double max_large_center_distance = 5.5;
  const double armor_max_angle = 25;

  struct Light : public cv::RotatedRect
  {
    Light() = default;
    explicit Light(cv::RotatedRect box) : cv::RotatedRect(box)
    {
      cv::Point2f p[4];
      box.points(p);
      std::sort(p, p + 4, [](const cv::Point2f &a, const cv::Point2f &b)
                { return a.y < b.y; });
      top = (p[0] + p[1]) / 2;
      bottom = (p[2] + p[3]) / 2;

      length = cv::norm(top - bottom);
      width = cv::norm(p[0] - p[1]);

      tilt_angle = std::atan2(std::abs(top.x - bottom.x), std::abs(top.y - bottom.y));
      tilt_angle = tilt_angle / CV_PI * 180;
    }

    cv::Point2f top, bottom;
    double length;
    double width;
    float tilt_angle;
  };

  struct Armor
  {
    Armor() = default;
    Armor(const Light &l1, const Light &l2)
    {
      if (l1.center.x < l2.center.x)
      {
        left_light = l1, right_light = l2;
      }
      else
      {
        left_light = l2, right_light = l1;
      }
    }

    // Light pairs part
    Light left_light, right_light;
    ArmorType type;
  };

  class OpenVINODetector
  {

  public:
    // bool isBigArmor(const ArmorObject &obj);
    /**
     * @brief Construct a new OpenVINO Detector object
     *
     * @param model_path IR/ONNX file path
     * @param device_name Target device (CPU, GPU, AUTO)
     * @param conf_threshold Confidence threshold for output filtering
     * @param top_k Topk parameter
     * @param nms_threshold NMS threshold
     * @param auto_init If initializing detector inplace
     */
    explicit OpenVINODetector(const std::string &model_path,
                              const std::string &device_name,
                              int binary_thres = 120,
                              float conf_threshold = 0.25, int top_k = 128,
                              float nms_threshold = 0.3, bool auto_init = false);

    /**
     * @brief Initialize detector
     *
     */
    void init();

    bool detect(cv::Mat &rgb_img, std::vector<ArmorObject> &objs);

    cv::Mat getAllBinary();
std::unique_ptr<NumberClassifier> number_classifier_;
  private:
    cv::Mat preprocessROI(const cv::Mat &img, cv::Rect armor_box);
    bool isLight(const Light &light);
    std::vector<Light> findLight(const cv::Mat &binary_img);
    ArmorType isArmor(const Light &light_1, const Light &light_2);
    std::vector<Armor> matchLights(const std::vector<Light> &lights);
    void tradition(cv::Mat &input_img, std::vector<ArmorObject> &armors_data);
    void blowUpBox(cv::Rect &box);
    Armor findMaxIouArmor(const std::vector<Armor> &armors, const cv::Rect &box, const std::vector<cv::Point2f> &points);
    
    
    
    std::vector<cv::Mat> roi_; 
    std::string model_path_;
    std::string device_name_;
    int binary_thres_ = 120;
    float conf_threshold_;
    int top_k_;
    float nms_threshold_;
    std::vector<int> strides_;
    std::vector<GridAndStride> grid_strides_;

    std::unique_ptr<ov::Core> ov_core_;
    ov::CompiledModel compiled_model_; // 可执行网络

    ov::InferRequest infer_request_; // 推理请求

    Eigen::Matrix<float, 3, 3> transform_matrix_;
  };
} // namespace rm_auto_aim

#endif // OPENVINO_ARMOR_DETECTOR__OPENVINO_DETECTOR_HPP_
