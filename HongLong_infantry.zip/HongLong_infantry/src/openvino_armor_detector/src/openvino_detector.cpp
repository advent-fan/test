// Copyright 2023 Yunlong Feng
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "openvino_armor_detector/openvino_detector.hpp"
#include <algorithm>
#include <chrono>
#include <ctime>

namespace rm_auto_aim
{

  static const int INPUT_W = 416;       // Width of input
  static const int INPUT_H = 416;       // Height of input
  static constexpr int NUM_CLASSES = 8; // Number of classes
  static constexpr int NUM_COLORS = 8;  // Number of color
  static constexpr float MERGE_CONF_ERROR = 0.15;
  static constexpr float MERGE_MIN_IOU = 0.9;

  static cv::Mat letterbox(const cv::Mat &img, Eigen::Matrix3f &transform_matrix,
                           std::vector<int> new_shape = {INPUT_W, INPUT_H})
  {
    // Get current image shape [height, width]

    int img_h = img.rows;
    int img_w = img.cols;

    // Compute scale ratio(new / old) and target resized shape
    float scale =
        std::min(new_shape[1] * 1.0 / img_h, new_shape[0] * 1.0 / img_w);
    int resize_h = static_cast<int>(round(img_h * scale));
    int resize_w = static_cast<int>(round(img_w * scale));

    // Compute padding
    int pad_h = new_shape[1] - resize_h;
    int pad_w = new_shape[0] - resize_w;

    // Resize and pad image while meeting stride-multiple constraints
    cv::Mat resized_img;
    cv::resize(img, resized_img, cv::Size(resize_w, resize_h));

    // divide padding into 2 sides
    float half_h = pad_h * 1.0 / 2;
    float half_w = pad_w * 1.0 / 2;

    // Compute padding boarder
    int top = static_cast<int>(round(half_h - 0.1));
    int bottom = static_cast<int>(round(half_h + 0.1));
    int left = static_cast<int>(round(half_w - 0.1));
    int right = static_cast<int>(round(half_w + 0.1));

    /* clang-format off */
  /* *INDENT-OFF* */

  // Compute point transform_matrix
  transform_matrix << 1.0 / scale, 0, -half_w / scale,
                      0, 1.0 / scale, -half_h / scale,
                      0, 0, 1;

  /* *INDENT-ON* */
    /* clang-format on */

    // Add border
    cv::copyMakeBorder(resized_img, resized_img, top, bottom, left, right,
                       cv::BORDER_CONSTANT, cv::Scalar(114, 114, 114));

    return resized_img;
  }

  /**
   * @brief Generate grids and stride.
   * @param target_w Width of input.
   * @param target_h Height of input.
   * @param strides A vector of stride.
   * @param grid_strides Grid stride generated in this function.
   */
  static void
  generate_grids_and_stride(const int target_w, const int target_h,
                            std::vector<int> &strides,
                            std::vector<GridAndStride> &grid_strides)
  {
    for (auto stride : strides)
    {
      int num_grid_w = target_w / stride;
      int num_grid_h = target_h / stride;

      for (int g1 = 0; g1 < num_grid_h; g1++)
      {
        for (int g0 = 0; g0 < num_grid_w; g0++)
        {
          grid_strides.emplace_back(GridAndStride{g0, g1, stride});
        }
      }
    }
  }

  static ArmorType judgeArmorType(std::vector<cv::Point2f> &pts)
  {

    float light_1_lenght = cv::norm(pts[0] - pts[1]);
    float light_2_lenght = cv::norm(pts[3] - pts[2]);

    float avg_light_length = (light_1_lenght + light_2_lenght) / 2;

    cv::Point2f light_1_center = (pts[0] + pts[1]) / 2;
    cv::Point2f light_2_center = (pts[3] + pts[2]) / 2;
    float center_distance =
        cv::norm(light_1_center - light_2_center) / avg_light_length;

    return center_distance > min_large_center_distance ? ArmorType::BIG
                                                       : ArmorType::SMALL;
  }

  static void generate_proposals(
      std::vector<ArmorObject> &output_objs, std::vector<float> &scores,
      std::vector<cv::Rect> &rects, const cv::Mat &output_buffer,
      const Eigen::Matrix<float, 3, 3> &transform_matrix, float conf_threshold,
      std::vector<GridAndStride> grid_strides)
  {
    const int num_anchors = grid_strides.size();

    for (int anchor_idx = 0; anchor_idx < num_anchors; anchor_idx++)
    {
      float confidence = output_buffer.at<float>(anchor_idx, 8);
      if (confidence < conf_threshold)
      {
        continue;
      }
      double color_score, num_score;
      cv::Point color_id, num_id;
      cv::Mat color_scores =
          output_buffer.row(anchor_idx).colRange(9, 9 + NUM_COLORS);
      cv::minMaxLoc(color_scores, NULL, &color_score, NULL, &color_id);
      if (color_id.x > 3)
      {
        // 过滤颜色
        continue;
      }

      cv::Mat num_scores =
          output_buffer.row(anchor_idx)
              .colRange(9 + NUM_COLORS, 9 + NUM_COLORS + NUM_CLASSES);
      // Argmax
      cv::minMaxLoc(num_scores, NULL, &num_score, NULL, &num_id);

      const int grid0 = grid_strides[anchor_idx].grid0;
      const int grid1 = grid_strides[anchor_idx].grid1;
      const int stride = grid_strides[anchor_idx].stride;

      float x_1 = (output_buffer.at<float>(anchor_idx, 0) + grid0) * stride;
      float y_1 = (output_buffer.at<float>(anchor_idx, 1) + grid1) * stride;
      float x_2 = (output_buffer.at<float>(anchor_idx, 2) + grid0) * stride;
      float y_2 = (output_buffer.at<float>(anchor_idx, 3) + grid1) * stride;
      float x_3 = (output_buffer.at<float>(anchor_idx, 4) + grid0) * stride;
      float y_3 = (output_buffer.at<float>(anchor_idx, 5) + grid1) * stride;
      float x_4 = (output_buffer.at<float>(anchor_idx, 6) + grid0) * stride;
      float y_4 = (output_buffer.at<float>(anchor_idx, 7) + grid1) * stride;

      Eigen::Matrix<float, 3, 4> apex_norm;
      Eigen::Matrix<float, 3, 4> apex_dst;

      /* clang-format off */
    /* *INDENT-OFF* */
    apex_norm << x_1, x_2, x_3, x_4,
                y_1, y_2, y_3, y_4,
                1,   1,   1,   1;
    /* *INDENT-ON* */
      /* clang-format on */

      apex_dst = transform_matrix * apex_norm;

      ArmorObject obj;

      obj.pts.resize(4);

      obj.pts[0] = cv::Point2f(apex_dst(0, 0), apex_dst(1, 0));
      obj.pts[1] = cv::Point2f(apex_dst(0, 1), apex_dst(1, 1));
      obj.pts[2] = cv::Point2f(apex_dst(0, 2), apex_dst(1, 2));
      obj.pts[3] = cv::Point2f(apex_dst(0, 3), apex_dst(1, 3));

      auto rect = cv::boundingRect(obj.pts);

      obj.box = rect;
      obj.color = color_id.x > 1 ? RED : BLUE;
      obj.number = NUMBER[num_id.x];
      obj.prob = confidence;
      obj.type = judgeArmorType(obj.pts);

      rects.push_back(rect);
      scores.push_back(confidence);
      output_objs.push_back(std::move(obj));
    }
  }

  /**
   * @brief Calculate intersection area between two objects.
   * @param a Object a.
   * @param b Object b.
   * @return Area of intersection.
   */
  static inline float intersection_area(const ArmorObject &a,
                                        const ArmorObject &b)
  {
    cv::Rect_<float> inter = a.box & b.box;
    return inter.area();
  }

  static void nms_merge_sorted_bboxes(std::vector<ArmorObject> &faceobjects,
                                      std::vector<int> &indices,
                                      float nms_threshold)
  {
    indices.clear();

    const int n = faceobjects.size();

    std::vector<float> areas(n);
    for (int i = 0; i < n; i++)
    {
      areas[i] = faceobjects[i].box.area();
    }

    for (int i = 0; i < n; i++)
    {
      ArmorObject &a = faceobjects[i];

      int keep = 1;
      for (size_t j = 0; j < indices.size(); j++)
      {
        ArmorObject &b = faceobjects[indices[j]];

        // intersection over union
        float inter_area = intersection_area(a, b);
        float union_area = areas[i] + areas[indices[j]] - inter_area;
        float iou = inter_area / union_area;
        if (iou > nms_threshold || isnan(iou))
        {
          keep = 0;
          // Stored for Merge
          if (a.number == b.number && a.color == b.color && iou > MERGE_MIN_IOU &&
              abs(a.prob - b.prob) < MERGE_CONF_ERROR)
          {
            for (int i = 0; i < 4; i++)
            {
              b.pts.push_back(a.pts[i]);
            }
          }
          // cout<<b.pts_x.size()<<endl;
        }
      }

      if (keep)
      {
        indices.push_back(i);
      }
    }
  }
  OpenVINODetector::OpenVINODetector(const std::string &model_path,
                                     const std::string &device_name,
                                     int binary_thresh,
                                     float conf_threshold, int top_k,
                                     float nms_threshold, bool auto_init)
      : model_path_(model_path), device_name_(device_name), binary_thres_(binary_thresh),
        conf_threshold_(conf_threshold), top_k_(top_k),
        nms_threshold_(nms_threshold)
  {
    if (auto_init)
    {
      init();
    }
  }

  void OpenVINODetector::init()
  {
    if (ov_core_ == nullptr)
    {
      ov_core_ = std::make_unique<ov::Core>();
    }

    ov_core_->set_property("CPU", ov::enable_profiling(true));

    auto model = ov_core_->read_model(model_path_);

    if (model.get() == nullptr)
    {
      printf("model is null\n");
    }

    // Set infer type
    ov::preprocess::PrePostProcessor ppp(model);
    ppp.build();
    // Set input output precision
    ppp.input().tensor().set_element_type(ov::element::f32);
    ppp.output().tensor().set_element_type(ov::element::f32);

    // Compile model
    compiled_model_ = ov_core_->compile_model(
        model, device_name_,
        ov::hint::performance_mode(ov::hint::PerformanceMode::LATENCY));

    strides_ = {8, 16, 32};
    generate_grids_and_stride(INPUT_W, INPUT_H, strides_, grid_strides_);

    infer_request_ = compiled_model_.create_infer_request();
  }

  bool OpenVINODetector::detect(cv::Mat &rgb_img,
                                std::vector<ArmorObject> &objs_result)
  {

    if (rgb_img.empty())
    {
      return false;
    }
    cv::Mat resized_img = letterbox(rgb_img, transform_matrix_);

    cv::Mat blob = cv::dnn::blobFromImage(
        resized_img, 1., cv::Size(INPUT_W, INPUT_H), cv::Scalar(0, 0, 0), true);

    // Feed blob into input

    /* code */
    auto input_port = compiled_model_.input();
    ov::Tensor input_tensor(
        input_port.get_element_type(),
        ov::Shape(std::vector<size_t>{1, 3, INPUT_W, INPUT_H}), blob.ptr(0));

    // Start inference
    infer_request_.set_input_tensor(input_tensor);
    infer_request_.infer();

    auto output = infer_request_.get_output_tensor();

    // Process output data
    auto output_shape = output.get_shape();

    // 3549 x 21 Matrix
    cv::Mat output_buffer(output_shape[1], output_shape[2], CV_32F,
                          output.data());

    // Parsed variable
    std::vector<ArmorObject> objs_tmp;
    std::vector<cv::Rect> rects;
    std::vector<float> scores;
    std::vector<int> indices;

    // Parse YOLO output
    generate_proposals(objs_tmp, scores, rects, output_buffer, transform_matrix_,
                       this->conf_threshold_, this->grid_strides_);

    // TopK
    std::sort(objs_tmp.begin(), objs_tmp.end(),
              [](const ArmorObject &a, const ArmorObject &b)
              {
                return a.prob > b.prob;
              });
    if (objs_tmp.size() > static_cast<size_t>(this->top_k_))
    {
      objs_tmp.resize(this->top_k_);
    }

    nms_merge_sorted_bboxes(objs_tmp, indices, this->nms_threshold_);

    for (size_t i = 0; i < indices.size(); i++)
    {
      objs_result.push_back(std::move(objs_tmp[indices[i]]));
      if (objs_result[i].pts.size() >= 8)
      {
        auto N = objs_result[i].pts.size();
        cv::Point2f pts_final[4];

        for (size_t j = 0; j < N; j++)
        {
          pts_final[j % 4] += objs_result[i].pts[j];
        }

        objs_result[i].pts.resize(4);
        for (int j = 0; j < 4; j++)
        {
          pts_final[j].x /= static_cast<float>(N) / 4.0;
          pts_final[j].y /= static_cast<float>(N) / 4.0;
          objs_result[i].pts[j] = pts_final[j];
        }
      }
    }
    tradition(rgb_img, objs_result);
    number_classifier_->classify(rgb_img, objs_result);

    return true;
  }

  void OpenVINODetector::blowUpBox(cv::Rect &rect)
  {
    cv::Point center(rect.x + rect.width / 2, rect.y + rect.height / 2);

    // 放大矩形
    rect.x = static_cast<int>(center.x - rect.width * 1.5 / 2);
    rect.y = static_cast<int>(center.y - rect.height * 2 / 2);
    rect.width = static_cast<int>(rect.width * 1.5);
    rect.height = static_cast<int>(rect.height * 2);
  }
  bool OpenVINODetector::isLight(const Light &light)
  {
    // The ratio of light (short side / long side)
    float ratio = light.width / light.length;
    bool ratio_ok = min_ratio < ratio && ratio < max_ratio;

    bool angle_ok = light.tilt_angle < light_max_angle;

    bool is_light = ratio_ok && angle_ok;

    return is_light;
  }

  ArmorType OpenVINODetector::isArmor(const Light &light_1, const Light &light_2)
  {
    // Ratio of the length of 2 lights (short side / long side)
    float light_length_ratio = light_1.length < light_2.length
                                   ? light_1.length / light_2.length
                                   : light_2.length / light_1.length;
    bool light_ratio_ok = light_length_ratio > min_light_ratio;

    // Distance between the center of 2 lights (unit : light length)
    float avg_light_length = (light_1.length + light_2.length) / 2;
    float center_distance =
        cv::norm(light_1.center - light_2.center) / avg_light_length;
    bool center_distance_ok = (min_small_center_distance <= center_distance &&
                               center_distance < max_small_center_distance) ||
                              (min_large_center_distance <= center_distance &&
                               center_distance < max_large_center_distance);

    // Angle of light center connection
    cv::Point2f diff = light_1.center - light_2.center;
    float angle = std::abs(std::atan(diff.y / diff.x)) / CV_PI * 180;
    bool angle_ok = angle < armor_max_angle;

    bool is_armor = light_ratio_ok && center_distance_ok && angle_ok;
    // printf("light_ratio_ok:%d, center_distance_ok:%d, angle_ok:%d\n", light_ratio_ok, center_distance_ok, angle_ok);

    // Judge armor type
    ArmorType type;
    if (is_armor)
    {
      type = center_distance > min_large_center_distance ? ArmorType::BIG
                                                         : ArmorType::SMALL;
    }
    else
    {
      type = ArmorType::INVALID;
    }
    // printf("type:%d\n", type);
    return type;
  }
  std::vector<Armor> OpenVINODetector::matchLights(const std::vector<Light> &lights)
  {
    std::vector<Armor> armors;
    // Loop all the pairing of lights
    for (auto light_1 = lights.begin(); light_1 != lights.end(); light_1++)
    {
      for (auto light_2 = light_1 + 1; light_2 != lights.end(); light_2++)
      {

        auto type = isArmor(*light_1, *light_2);
        if (type != ArmorType::INVALID)
        {
          auto armor = Armor(*light_1, *light_2);
          armor.type = type;
          armors.emplace_back(armor);
        }
      }
    }

    return armors;
  }

  std::vector<Light> OpenVINODetector::findLight(const cv::Mat &binary_img)
  {
    using std::vector;
    vector<vector<cv::Point>> contours;
    vector<cv::Vec4i> hierarchy;
    cv::findContours(binary_img, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    vector<Light> lights;
    for (const auto &contour : contours)
    {
      auto r_rect = cv::minAreaRect(contour);
      auto light = Light(r_rect);

      if (isLight(light))
      {
        auto rect = light.boundingRect();
        if ( // Avoid assertion failed
            0 <= rect.x && 0 <= rect.width && rect.x + rect.width <= binary_img.cols && 0 <= rect.y &&
            0 <= rect.height && rect.y + rect.height <= binary_img.rows)
        {
          lights.emplace_back(light);
        }
      }
    }

    return lights; // 这里已经成功找到一个装甲板的两个或一个灯条
  }

  cv::Mat OpenVINODetector::preprocessROI(const cv::Mat &img, cv::Rect armor_box)
  {

    cv::Mat roi = img(armor_box);

    // cv::Mat pre_gray;
    cv::Mat gray_img;

    cv::cvtColor(roi, gray_img, cv::COLOR_RGB2GRAY);

    cv::Mat binary_img;
    cv::threshold(gray_img, binary_img, binary_thres_, 255, cv::THRESH_BINARY);
    // cv::morphologyEx(binary_img, binary_img, cv::MORPH_OPEN, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3)));

    return binary_img;
  }

  void OpenVINODetector::tradition(cv::Mat &input_img, std::vector<ArmorObject> &armors_data)
  {
    if (armors_data.empty())
    {
      return;
    }
    roi_.clear();

    for (auto &armor_obj : armors_data)
    {

      blowUpBox(armor_obj.box);

      if (armor_obj.box.x < 0 || armor_obj.box.y < 0 || (armor_obj.box.height + armor_obj.box.y) > input_img.rows || (armor_obj.box.width + armor_obj.box.x) > input_img.cols)
      {
        continue;
      }

      cv::Mat roi_binary_img = preprocessROI(input_img, armor_obj.box);
      roi_.push_back(roi_binary_img);
      // cv::Mat rbg_img = input_img(armor_obj.box);

      std::vector<Light> lights = findLight(roi_binary_img);
      
      if (lights.size() < 2)
      {
        continue;
      }
      std::vector<Armor> armors = matchLights(lights);
      // printf("armors.size() = %d\n",armors.size());
      if (armors.size() == 0)
      {
        // armors_data.erase(std::find(armors_data.begin(), armors_data.end(), armor_obj));
        continue;
      }
      Armor result_armor = armors.size() == 1 ? armors[0] : findMaxIouArmor(armors, armor_obj.box, armor_obj.pts);

      armor_obj.type = result_armor.type;
      armor_obj.pts[0] = result_armor.left_light.top + cv::Point2f(armor_obj.box.tl());
      armor_obj.pts[1] = result_armor.left_light.bottom + cv::Point2f(armor_obj.box.tl());
      armor_obj.pts[2] = result_armor.right_light.bottom + cv::Point2f(armor_obj.box.tl());
      armor_obj.pts[3] = result_armor.right_light.top + cv::Point2f(armor_obj.box.tl());
    }
  }

  Armor OpenVINODetector::findMaxIouArmor(const std::vector<Armor> &armors, const cv::Rect &box, const std::vector<cv::Point2f> &points)
  {
    Armor result_armor;
    double max_iou = 0;
    std::vector<cv::Point2f> polygon = {points[0], points[1], points[2], points[3]};
    std::vector<cv::Point2f> hull;
    cv::convexHull(polygon, hull);
    for (const Armor &a : armors)
    {
      std::vector<cv::Point2f> polygon_a = {a.left_light.top + cv::Point2f(box.tl()), a.left_light.bottom + cv::Point2f(box.tl()), a.right_light.bottom + cv::Point2f(box.tl()), a.right_light.top + cv::Point2f(box.tl())};
      std::vector<cv::Point2f> hull_a;
      cv::convexHull(polygon_a, hull_a);
      std::vector<cv::Point2f> intersection;
      cv::intersectConvexConvex(hull, hull_a, intersection);
      std::vector<cv::Point2f> unionPoints = hull;
      unionPoints.insert(unionPoints.end(), hull_a.begin(), hull_a.end());
      // 计算并集的凸包
      std::vector<cv::Point2f> unionHull;
      cv::convexHull(unionPoints, unionHull);
      // 计算并集和交集的面积
      double intersectionArea = intersection.empty() ? 0.0 : cv::contourArea(intersection);
      double unionArea = cv::contourArea(unionHull);
      // 计算并比
      double iou = intersectionArea / unionArea;
      if (iou > max_iou)
      {
        max_iou = iou;
        result_armor = a;
      }
    }
    return result_armor;
  }

  cv::Mat OpenVINODetector::getAllBinary()
  {
    if (roi_.empty())
    {
      return cv::Mat(cv::Size(20, 28), CV_8UC1);
    }
    else
    {
      // cv::Mat all_bin_img;
      // cv::vconcat(roi_, all_bin_img);
      return roi_[0];
    }
  }
} // namespace rm_auto_aim
