#ifndef TRAJECTORY_SOLVE__TRAJECTORY_SOLVE_NODE_HPP_
#define TRAJECTORY_SOLVE__TRAJECTORY_SOLVE_NODE_HPP_

#include <message_filters/subscriber.h>
#include <tf2_ros/buffer.h>
#include <tf2_ros/create_timer_ros.h>
#include <tf2_ros/message_filter.h>
#include <tf2_ros/transform_listener.h>

#include <memory>
#include <string>

#include <rclcpp/rclcpp.hpp>

#include <auto_aim_interfaces/msg/target.hpp>
#include <control_interfaces/msg/gimbal_command.hpp>
#include <rmoss_projectile_motion/projectile_solver_interface.hpp>
#include <visualization_msgs/msg/marker.hpp>
#include <Eigen/Dense>
// #include <rmoss_projectile_motion/gimbal_transform_tool.hpp>
// #include <rmoss_projectile_motion/projectile_solver_interface.hpp>
// #include <rm_interfaces/msg/gimbal_cmd.hpp>
// #include <rm_interfaces/msg/robot_shoot_data.hpp>

namespace rm_trajectory_solve
{

  class TrajectorySolveNode : public rclcpp::Node
  {
  public:
    using tf2_filter = tf2_ros::MessageFilter<auto_aim_interfaces::msg::Target>;

  public:
    explicit TrajectorySolveNode(rclcpp::NodeOptions options);

  private:
    void targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr msg);
    // void shoot_data_callback(const rm_interfaces::msg::RobotShootData::SharedPtr msg);
    void pushliAimingPoint(Eigen::Vector3d aiming_point);
    bool judgeIsShoot(double relative_yaw, double relative_pitch, Eigen::Vector3d aiming_point, std::string id, int armors_num); // 判断是否可以发射


  private:
    double offset_x_;
    double offset_y_;
    double offset_z_;
    double offset_pitch_;
    double offset_yaw_;
    double offset_time_;
    double shoot_speed_;
    double friction_{0.001};

    std::string target_topic_;
    std::string gimbal_cmd_topic_;
    std::string shoot_data_topic_;
    std::string solver_type_;
    std::string shooter_frame_;


    visualization_msgs::msg::Marker aiming_point_; // for rviz
    rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr marker_pub_;

    std::shared_ptr<rmoss_projectile_motion::ProjectileSolverInterface> solver_;
    rclcpp::Subscription<auto_aim_interfaces::msg::Target>::SharedPtr target_subscriber_;
    rclcpp::Publisher<control_interfaces::msg::GimbalCommand>::SharedPtr gimbal_cmd_publisher_;

    message_filters::Subscriber<auto_aim_interfaces::msg::Target> target_sub_;
    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    std::shared_ptr<tf2_filter> tf_filter_;

    static constexpr float SMALL_ARMOR_WIDTH = 0.135;//m
    static constexpr float SMALL_ARMOR_HEIGHT = 0.125;
    static constexpr float LARGE_ARMOR_WIDTH = 0.225;
    static constexpr float LARGE_ARMOR_HEIGHT = 0.125;
  };

} // namespace projectile_motion

#endif // PROJECTILE_MOTION__PROJECTILE_MOTION_NODE_HPP_