#include <trajectory_solve/trajectory_solve_node.hpp>

#include <geometry_msgs/msg/pose_stamped.hpp>

#include <rmoss_projectile_motion/gravity_projectile_solver.hpp>
#include <rmoss_projectile_motion/gaf_projectile_solver.hpp>

namespace rm_trajectory_solve
{
    TrajectorySolveNode::TrajectorySolveNode(rclcpp::NodeOptions options)
        : Node("trajectory_solve_node", options.use_intra_process_comms(true))
    {
        RCLCPP_INFO(this->get_logger(), "start trajectory_solve_node");
        offset_x_ = this->declare_parameter("offset_x", 0.0);
        offset_y_ = this->declare_parameter("offset_y", 0.0);
        offset_z_ = this->declare_parameter("offset_z", 0.0);
        offset_pitch_ = this->declare_parameter("offset_pitch", 0.0);
        offset_yaw_ = this->declare_parameter("offset_yaw", 0.0);
        offset_time_ = this->declare_parameter("offset_time", 0.0);
        shoot_speed_ = this->declare_parameter("initial_speed", 25.0);
        target_topic_ = this->declare_parameter("target_topic", "/tracker/target");
        gimbal_cmd_topic_ = this->declare_parameter("gimbal_cmd_topic", "/gimbal_cmd");
        shoot_data_topic_ = this->declare_parameter("shoot_data_topic", "robot_shoot_data");
        solver_type_ = this->declare_parameter("solver_type", "gravity");
        shooter_frame_ = this->declare_parameter("target_frame", "shooter_link");

        aiming_point_.header.frame_id = "odom";
        aiming_point_.ns = "aiming_point";
        aiming_point_.type = visualization_msgs::msg::Marker::SPHERE;
        aiming_point_.action = visualization_msgs::msg::Marker::ADD;
        aiming_point_.scale.x = aiming_point_.scale.y = aiming_point_.scale.z =
            0.12;
        aiming_point_.color.r = 1.0;
        aiming_point_.color.g = 1.0;
        aiming_point_.color.b = 1.0;
        aiming_point_.color.a = 1.0;
        aiming_point_.lifetime = rclcpp::Duration::from_seconds(0.1);

        RCLCPP_INFO(this->get_logger(), "trajectory_solve type: %s", solver_type_.c_str());
        if (solver_type_ == "gravity")
        {
            solver_ = std::make_shared<rmoss_projectile_motion::GravityProjectileSolver>(shoot_speed_);
        }
        else if (solver_type_ == "gaf")
        {
            friction_ = this->declare_parameter("friction", 0.001);
            solver_ =
                std::make_shared<rmoss_projectile_motion::GafProjectileSolver>(shoot_speed_, friction_);
        }
        else
        {
            RCLCPP_ERROR(this->get_logger(), "Unknown solver type: %s", solver_type_.c_str());
            return;
        }

        gimbal_cmd_publisher_ = this->create_publisher<control_interfaces::msg::GimbalCommand>(
            gimbal_cmd_topic_,
            10);
        marker_pub_ = this->create_publisher<visualization_msgs::msg::Marker>("aiming_point", 10);

        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        // Create the timer interface before call to waitForTransform,
        // to avoid a tf2_ros::CreateTimerInterfaceException exception
        auto timer_interface = std::make_shared<tf2_ros::CreateTimerROS>(
            this->get_node_base_interface(), this->get_node_timers_interface());
        tf_buffer_->setCreateTimerInterface(timer_interface);
        tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
        target_sub_.subscribe(this, target_topic_, rclcpp::SensorDataQoS().get_rmw_qos_profile());
        tf_filter_ =
            std::make_shared<tf2_filter>(
                target_sub_, *tf_buffer_, shooter_frame_, 10, this->get_node_logging_interface(),
                this->get_node_clock_interface(), std::chrono::duration<int>(1));
        tf_filter_->registerCallback(&TrajectorySolveNode::targetCallback, this);

        RCLCPP_INFO(this->get_logger(), "Projectile motion node initialized.");
    }

    // void TrajectorySolveNode::targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr msg)
    // {
    //     if (!msg->tracking)
    //     {
    //         return;
    //     }
    //     // Get current gimbal angle.
    //     double cur_roll, cur_pitch, cur_yaw;
    //     try
    //     {
    //         auto transfrom = tf_buffer_->lookupTransform(
    //             msg->header.frame_id, shooter_frame_,
    //             msg->header.stamp);
    //         tf2::Quaternion rot_q(transfrom.transform.rotation.x, transfrom.transform.rotation.y,
    //                               transfrom.transform.rotation.z, transfrom.transform.rotation.w);
    //         tf2::Matrix3x3 rot_m(rot_q);

    //         rot_m.getRPY(cur_roll, cur_pitch, cur_yaw);
    //     }
    //     catch (const tf2::ExtrapolationException &ex)
    //     {
    //         RCLCPP_ERROR(get_logger(), "Error while transforming %s", ex.what());
    //         return;
    //     }

    //     // Calculate the targets position at current time.
    //     rclcpp::Time target_time = msg->header.stamp;
    //     auto center_position =
    //         Eigen::Vector3d(
    //             msg->position.x + offset_x_, msg->position.y + offset_y_,
    //             msg->position.z + offset_z_);
    //     auto center_velocity = Eigen::Vector3d(msg->velocity.x, msg->velocity.y, msg->velocity.z);

    //     // Calculate each target position at current time & predict time.
    //     double min_yaw = DBL_MAX, min_dis = DBL_MAX;
    //     double hit_yaw, hit_pitch;
    //     bool is_current_pair = true;
    //     double r = 0., target_dz = 0., fly_time = 0.;
    //     double target_pitch, target_yaw;
    //     Eigen::Vector3d target_position, target_predict_position;
    //     for (int i = 0; i < msg->armors_num; ++i)
    //     {
    //         double tmp_yaw = msg->yaw + i * (2 * M_PI / msg->armors_num);
    //         if (msg->armors_num == 4)
    //         {
    //             r = is_current_pair ? msg->radius_1 : msg->radius_2;
    //             is_current_pair = !is_current_pair;
    //             target_dz = is_current_pair ? 0. : msg->dz;
    //         }
    //         else
    //         {
    //             r = msg->radius_1;
    //             target_dz = 0.;
    //         }
    //         target_position = center_position + Eigen::Vector3d(
    //                                                 -r * std::cos(tmp_yaw), -r * std::sin(tmp_yaw),
    //                                                 target_dz);

    //         // Use distance to calculate the time offset. (Approximate)
    //         fly_time = target_position.head(2).norm() / shoot_speed_ + offset_time_;
    //         tmp_yaw = tmp_yaw + msg->v_yaw * fly_time;
    //         target_predict_position = center_position + center_velocity * fly_time +
    //                                   Eigen::Vector3d(
    //                                       -r * std::cos(tmp_yaw), -r * std::sin(tmp_yaw),
    //                                       target_dz);

    //         solver_->solve(
    //             target_predict_position.head(2).norm(), target_predict_position.z(),
    //             target_pitch);
    //         target_pitch = -target_pitch; // Right-handed system
    //         target_yaw = std::atan2(target_predict_position.y(), target_predict_position.x());

    //         // Choose the target with minimum yaw error.
    //         if (::abs(
    //                 ::fmod(
    //                     tmp_yaw,
    //                     M_PI) -
    //                 cur_yaw) < min_yaw &&
    //             target_predict_position.head(2).norm() < min_dis)
    //         {
    //             min_yaw = ::abs(::fmod(tmp_yaw, M_PI) - cur_yaw);
    //             min_dis = target_predict_position.head(2).norm();
    //             hit_yaw = target_yaw;
    //             hit_pitch = target_pitch;
    //         }
    //     }

    //     // Publish the gimbal command.
    //     auto yaw = hit_yaw - cur_yaw;
    //     auto pitch = hit_pitch - cur_pitch;
    //     auto gimbal_cmd = control_interfaces::msg::GimbalCommand();
    //     gimbal_cmd.pitch = pitch + offset_pitch_;
    //     gimbal_cmd.yaw = yaw + offset_yaw_;
    //     gimbal_cmd.is_shoot=false;
    //     gimbal_cmd_publisher_->publish(gimbal_cmd);
    // }

    void TrajectorySolveNode::targetCallback(const auto_aim_interfaces::msg::Target::SharedPtr msg)
    {

        if (!msg->tracking)
        {
            return;
        }
        // 获取但前时刻的角度
        double cur_roll, cur_pitch, cur_yaw;

        try
        {
            auto transfrom = tf_buffer_->lookupTransform(
                msg->header.frame_id, shooter_frame_,
                this->get_clock()->now(), rclcpp::Duration::from_nanoseconds(5000));
            tf2::Quaternion rot_q(transfrom.transform.rotation.x, transfrom.transform.rotation.y,
                                  transfrom.transform.rotation.z, transfrom.transform.rotation.w);
            tf2::Matrix3x3 rot_m(rot_q);

            rot_m.getRPY(cur_roll, cur_pitch, cur_yaw);
        }
        catch (const tf2::ExtrapolationException &ex)
        {
            RCLCPP_WARN(get_logger(), "Error while transforming %s", ex.what());
            return;
        }

        // Calculate the targets position at current time.
        // 计算目标在当前时刻的位置
        rclcpp::Time target_time = msg->header.stamp;
        auto center_position =
            Eigen::Vector3d(
                msg->position.x + offset_x_, msg->position.y + offset_y_,
                msg->position.z + offset_z_);
        auto center_velocity = Eigen::Vector3d(msg->velocity.x, msg->velocity.y, msg->velocity.z);

        // Calculate each target position at current time & predict time.
        double min_yaw = DBL_MAX, min_dis = DBL_MAX;
        double hit_yaw, hit_pitch;
        bool is_current_pair = true;
        double r = 0., target_dz = 0., fly_time = 0.;
        double target_pitch, target_yaw;
        Eigen::Vector3d target_position, target_predict_position, aiming_point;
        double diff_time = (this->get_clock()->now() - msg->header.stamp).seconds(); // 图像数据从采集开始计时，到被用于状态估计，这段时间差为diff_time
        for (int i = 0; i < msg->armors_num; ++i)
        {
            double tmp_yaw = msg->yaw + i * (2 * M_PI / msg->armors_num);
            if (msg->armors_num == 4)
            {
                r = is_current_pair ? msg->radius_1 : msg->radius_2;
                is_current_pair = !is_current_pair;
                target_dz = is_current_pair ? 0. : msg->dz;
            }
            else
            {
                r = msg->radius_1;
                target_dz = 0.;
            }
            target_position = center_position + Eigen::Vector3d(
                                                    -r * std::cos(tmp_yaw), -r * std::sin(tmp_yaw),
                                                    target_dz);

            // Use distance to calculate the time offset. (Approximate)
            offset_time_ = this->get_parameter("offset_time").as_double();
            fly_time = target_position.head(2).norm() / shoot_speed_ + offset_time_;
            tmp_yaw = tmp_yaw + msg->v_yaw * (fly_time + diff_time);
            target_predict_position = center_position + center_velocity * (fly_time + diff_time) +
                                      Eigen::Vector3d(
                                          -r * std::cos(tmp_yaw), -r * std::sin(tmp_yaw),
                                          target_dz);

            solver_->solve(
                target_predict_position.head(2).norm()-0.1, target_predict_position.z(),
                target_pitch);
            // target_pitch = std::atan2(target_predict_position.z(), target_predict_position.head(2).norm());
            
            target_pitch = -target_pitch; // Right-handed system
            target_yaw = std::atan2(target_predict_position.y(), target_predict_position.x());

            // Choose the target with minimum yaw error.
            if (::abs(
                    ::fmod(
                        tmp_yaw,
                        M_PI) -
                    cur_yaw) < min_yaw &&
                target_predict_position.head(2).norm() < min_dis)
            {
                aiming_point = target_predict_position;
                min_yaw = ::abs(::fmod(tmp_yaw, M_PI) - cur_yaw);
                min_dis = target_predict_position.head(2).norm();
                hit_yaw = target_yaw;
                hit_pitch = target_pitch;
            }
        }
        pushliAimingPoint(aiming_point);

        // 将绝对角度转换为相对角度
        //  Publish the gimbal command.
        double relative_yaw = hit_yaw - cur_yaw;
        double relative_pitch = hit_pitch - cur_pitch;
        if (abs(relative_yaw) > M_PI)
        {
            relative_yaw = relative_yaw > 0 ? relative_yaw - 2 * M_PI : relative_yaw + 2 * M_PI;
        }
        hit_pitch = hit_pitch * 180 / M_PI;
        hit_yaw = hit_yaw * 180 / M_PI;
        relative_pitch = relative_pitch * 180 / M_PI;
        relative_yaw = relative_yaw * 180 / M_PI;
        offset_pitch_ = this->get_parameter("offset_pitch").as_double();
        offset_yaw_ = this->get_parameter("offset_yaw").as_double();
        auto gimbal_cmd = control_interfaces::msg::GimbalCommand();
        gimbal_cmd.header.stamp = this->now();
        gimbal_cmd.header.frame_id=shooter_frame_;
        
        gimbal_cmd.pitch = hit_pitch+ offset_pitch_;
        gimbal_cmd.yaw = hit_yaw + offset_yaw_;
        gimbal_cmd.debug_pitch=relative_pitch;
        gimbal_cmd.debug_yaw=relative_yaw;
        gimbal_cmd.is_shoot = judgeIsShoot(relative_yaw, relative_pitch, aiming_point, msg->id, msg->armors_num);
        gimbal_cmd_publisher_->publish(gimbal_cmd);
    }

    bool TrajectorySolveNode::judgeIsShoot(double relative_yaw, double relative_pitch, Eigen::Vector3d aiming_point, std::string id, int armors_num)
    {
        double armor_height = SMALL_ARMOR_HEIGHT;
        double armor_width = SMALL_ARMOR_WIDTH;

        if (id == "1" || id == "base" || armors_num == 2)
        {
            armor_height = LARGE_ARMOR_HEIGHT;
            armor_width = LARGE_ARMOR_WIDTH;
        }
        double distance = aiming_point.head(2).norm();
        // 先求yaw
        double theta_yaw = std::asin(armor_width / distance) * 180 / M_PI/2;
        bool yaw_ok = theta_yaw >= abs(relative_yaw);
        // 再求pitch
        double theta_pitch = std::asin(armor_height / distance) * 180 / M_PI/2;
        bool pitch_ok = theta_pitch >= abs(relative_pitch);
        return yaw_ok && pitch_ok;
    }

    void TrajectorySolveNode::pushliAimingPoint(Eigen::Vector3d aiming_point)
    {

        aiming_point_.header.stamp = this->now();
        aiming_point_.pose.position.x = aiming_point(0);
        aiming_point_.pose.position.y = aiming_point(1);
        aiming_point_.pose.position.z = aiming_point(2);
        marker_pub_->publish(aiming_point_);
    }
}
#include "rclcpp_components/register_node_macro.hpp"

// Register the component with class_loader.
// This acts as a sort of entry point, allowing the component to be discoverable when its library
// is being loaded into a running process.
RCLCPP_COMPONENTS_REGISTER_NODE(rm_trajectory_solve::TrajectorySolveNode)